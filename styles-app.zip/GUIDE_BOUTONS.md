# 🎨 Guide - Gestion des Couleurs des Boutons par Thème

## 🎯 Nouvelle Organisation

Les **couleurs des boutons** sont maintenant gérées **entièrement dans les thèmes** !

### Avant ❌

```scss
// components/_buttons.scss
.cc.vNextCM .button--primary {
    background-color: var(--clr-cm-dark);
    border-color: var(--clr-cm-dark);
}

.cc.vNextCIC .button--primary {
    background-color: var(--clr-cic);
    border-color: var(--clr-cic);
}
```

**Problème** : Les couleurs des thèmes dans le fichier des composants

---

### Après ✅

```scss
// components/_buttons.scss (Structure seulement)
@mixin button-primary($bg-color, $border-color, ...) {
    background-color: $bg-color;
    border-color: $border-color;
}

// themes/_credit-mutuel.scss (Couleurs ici !)
.cc.vNextCM .button--primary {
    @include btn.button-primary(
        $bg-color: var(--clr-cm-dark),
        $border-color: var(--clr-cm-dark)
    );
}
```

**Avantage** : Séparation claire structure / couleurs

---

## 📁 Organisation des Fichiers

### components/_buttons.scss

**Responsabilité** : Structure et mixins réutilisables SEULEMENT

```scss
// ✅ Structure de base
.cc .button {
    display: inline-flex;
    padding: 12px 24px;
    transition: all 0.3s;
}

// ✅ Mixins réutilisables
@mixin button-primary($bg-color, $border-color, ...) {
    // Structure commune
}

// ❌ PAS de couleurs spécifiques aux thèmes
```

---

### themes/_[nom-theme].scss

**Responsabilité** : Toutes les couleurs et styles spécifiques du thème

```scss
// ✅ Couleurs des boutons
.button--primary {
    @include btn.button-primary(
        $bg-color: var(--clr-cm-dark),
        $border-color: var(--clr-cm-dark)
    );
}

// ✅ Toutes les variantes
.button--primary--ghost { ... }
.button--link { ... }
.button--secondary { ... }
```

---

## 🎨 Mixins Disponibles

### button-primary

**Utilisation** :
```scss
@include btn.button-primary(
    $bg-color: #couleur,           // Couleur de fond
    $border-color: #couleur,       // Couleur bordure
    $text-color: #couleur,         // Couleur texte (défaut: blanc)
    $hover-bg: #couleur,           // Fond au hover (optionnel)
    $hover-border: #couleur        // Bordure au hover (optionnel)
);
```

**Exemple** :
```scss
.button--primary {
    @include btn.button-primary(
        $bg-color: var(--clr-cm-dark),
        $border-color: var(--clr-cm-dark),
        $text-color: var(--clr-white),
        $hover-bg: var(--clr-cm),
        $hover-border: var(--clr-cm)
    );
}
```

---

### button-ghost

**Utilisation** :
```scss
@include btn.button-ghost(
    $border-color: #couleur,       // Couleur bordure
    $text-color: #couleur,         // Couleur texte
    $hover-bg: #couleur,           // Fond au hover (optionnel)
    $hover-border: #couleur,       // Bordure au hover (optionnel)
    $hover-text: #couleur          // Texte au hover (optionnel)
);
```

**Exemple** :
```scss
.button--primary--ghost {
    @include btn.button-ghost(
        $border-color: var(--clr-cic),
        $text-color: var(--clr-cic),
        $hover-bg: var(--clr-cic-dark),
        $hover-border: var(--clr-cic),
        $hover-text: var(--clr-white)
    );
}
```

---

### button-link

**Utilisation** :
```scss
@include btn.button-link(
    $text-color: #couleur,         // Couleur texte
    $hover-color: #couleur         // Couleur au hover (optionnel)
);
```

**Exemple** :
```scss
.button--link {
    @include btn.button-link(
        $text-color: var(--clr-bt-dark),
        $hover-color: var(--clr-bt)
    );
}
```

---

## 📝 Exemples par Thème

### Credit Mutuel (Bleu)

```scss
.cc.vNextCM {
    .button {
        border-radius: var(--curve);  // Arrondi
        
        &--primary {
            @include btn.button-primary(
                $bg-color: var(--clr-cm-dark),      // Bleu foncé
                $border-color: var(--clr-cm-dark),
                $text-color: var(--clr-white)
            );
        }
        
        &--primary--ghost {
            @include btn.button-ghost(
                $border-color: var(--clr-cm),       // Bleu
                $text-color: var(--clr-cm),
                $hover-bg: var(--clr-cm-light),     // Bleu clair
                $hover-text: var(--clr-cm-dark)
            );
        }
        
        &--secondary {
            @include btn.button-primary(
                $bg-color: var(--clr-cm-accent),    // Rouge accent
                $border-color: var(--clr-cm-accent)
            );
        }
    }
}
```

---

### CIC (Turquoise)

```scss
.cc.vNextCIC {
    .button {
        border-radius: 0;  // Carré
        
        &--primary {
            @include btn.button-primary(
                $bg-color: var(--clr-cic),          // Turquoise
                $border-color: var(--clr-cic),
                $hover-bg: var(--clr-cic-dark)      // Turquoise foncé
            );
        }
        
        &--primary--ghost {
            @include btn.button-ghost(
                $border-color: var(--clr-cic),
                $text-color: var(--clr-cic),
                $hover-bg: var(--clr-cic-dark),
                $hover-text: var(--clr-white)       // Blanc au hover
            );
        }
    }
}
```

---

### Banque Tarneaud (Marine)

```scss
.cc.vNextBT {
    .button {
        border-radius: 0;
        font-family: 'Quicksand', serif;  // Font spécifique
        
        &--primary {
            @include btn.button-primary(
                $bg-color: var(--clr-bt-dark),      // Marine
                $border-color: var(--clr-bt-dark),
                $hover-bg: #244050                  // Marine + foncé
            );
        }
    }
}
```

---

### Banque Populaire (Rouge)

```scss
.cc.vNextBP {
    .button {
        border-radius: 0;
        
        &--primary {
            @include btn.button-primary(
                $bg-color: var(--clr-bp),           // Rouge
                $border-color: var(--clr-bp),
                $hover-bg: var(--clr-bp-dark)       // Rouge foncé
            );
        }
        
        &--secondary {
            @include btn.button-primary(
                $bg-color: var(--clr-bp-accent),    // Marron
                $border-color: var(--clr-bp-accent)
            );
        }
    }
}
```

---

## 🎯 Comment Modifier les Couleurs d'un Bouton

### Scénario 1 : Changer la couleur primary du thème CM

```scss
// 1. Ouvrir themes/_credit-mutuel.scss

// 2. Trouver .button--primary

// 3. Modifier les couleurs
.button--primary {
    @include btn.button-primary(
        $bg-color: #NEW_COLOR,  // ← Changer ici
        $border-color: #NEW_COLOR,
        $hover-bg: #NEW_COLOR_DARK
    );
}

// 4. Compiler
sass main.scss output.css
```

**Temps** : 1 minute ⚡

---

### Scénario 2 : Ajouter un nouveau type de bouton

```scss
// 1. Ouvrir themes/_nom-theme.scss

// 2. Ajouter un nouveau variant
.button--tertiary {
    @include btn.button-primary(
        $bg-color: var(--clr-grey),
        $border-color: var(--clr-grey),
        $text-color: var(--clr-white)
    );
}

// 3. Utiliser dans le HTML
<button class="button button--tertiary">Cliquez</button>
```

**Temps** : 5 minutes ⚡

---

### Scénario 3 : Modifier le hover d'un bouton ghost

```scss
// 1. Trouver .button--primary--ghost

// 2. Modifier les paramètres hover
.button--primary--ghost {
    @include btn.button-ghost(
        $border-color: var(--clr-cic),
        $text-color: var(--clr-cic),
        $hover-bg: #NEW_BG,        // ← Modifier
        $hover-text: #NEW_TEXT     // ← Modifier
    );
}
```

**Temps** : 2 minutes ⚡

---

## 📊 Avantages de cette Organisation

### ✅ Séparation des Responsabilités

```
components/_buttons.scss  → Structure
themes/_[theme].scss      → Couleurs
```

**Résultat** : Code plus clair et maintenable

---

### ✅ Facilité de Modification

**Avant** : Chercher dans components/_buttons.scss  
**Après** : Aller directement dans themes/_[theme].scss

**Gain** : -80% de temps de recherche

---

### ✅ Ajout de Thème Simplifié

```scss
// Nouveau thème : juste copier/coller et modifier les couleurs
.cc.vNextNOUVEAU {
    .button {
        &--primary {
            @include btn.button-primary(
                $bg-color: var(--clr-nouveau),
                $border-color: var(--clr-nouveau)
            );
        }
    }
}
```

**Temps** : 10 minutes au lieu de 1h

---

### ✅ Consistance Garantie

Tous les boutons utilisent les **mêmes mixins** → **même structure** pour tous les thèmes

---

## 🔍 Où Trouver Quoi ?

| Je veux... | J'ouvre... |
|------------|------------|
| Modifier la **structure** d'un bouton | `components/_buttons.scss` |
| Modifier les **couleurs** CM | `themes/_credit-mutuel.scss` |
| Modifier les **couleurs** CIC | `themes/_cic.scss` |
| Modifier les **couleurs** BT | `themes/_banque-tarneaud.scss` |
| Modifier les **couleurs** BP | `themes/_banque-populaire.scss` |
| Ajouter un **nouveau type** de bouton | Créer mixin dans `_buttons.scss` + utiliser dans thème |

---

## 🎓 Bonnes Pratiques

### ✅ À FAIRE

```scss
// Utiliser les mixins
@include btn.button-primary($bg-color: ..., ...);

// Nommer clairement les variants
.button--primary
.button--secondary
.button--tertiary

// Utiliser les variables CSS
$bg-color: var(--clr-cm-dark)

// Commenter les choix
// Bouton principal du thème - bleu foncé
```

---

### ❌ À ÉVITER

```scss
// Couleurs en dur
$bg-color: #164194

// Modifier directement les styles de base
.cc .button { color: red; }  // ❌ Aller dans le thème !

// Dupliquer le code
// Utiliser les mixins au lieu de répéter
```

---

## 🚀 Prochaines Étapes

### Immédiatement

1. ✅ Lire ce guide
2. ✅ Ouvrir un fichier thème
3. ✅ Modifier une couleur de bouton
4. ✅ Compiler et tester

---

### Cette Semaine

1. Personnaliser tous les boutons de ton thème
2. Ajouter des variantes si nécessaire
3. Tester tous les états (normal, hover, disabled)
4. Valider visuellement

---

### Ce Mois

1. Créer un guide de style visuel
2. Documenter tes conventions de couleurs
3. Optimiser les transitions
4. Ajouter des animations

---

## 📞 Questions Fréquentes

### Q : Puis-je encore modifier components/_buttons.scss ?

**R** : Oui, mais **uniquement pour la structure** (padding, display, transitions), **jamais les couleurs** !

---

### Q : Comment ajouter un bouton avec une icône ?

**R** : Ajoute le style de l'icône dans le thème :

```scss
.button--primary {
    @include btn.button-primary(...);
    
    svg {
        margin-left: 8px;
        @include colors.svg-filter-cm;
    }
}
```

---

### Q : Puis-je avoir des bordures différentes par thème ?

**R** : Oui ! Modifie `border-radius` dans le thème :

```scss
.cc.vNextCM .button {
    border-radius: var(--curve);  // Arrondi
}

.cc.vNextCIC .button {
    border-radius: 0;  // Carré
}
```

---

**Dernière mise à jour** : 30 novembre 2025  
**Version** : 2.1 - Gestion des couleurs par thème  
**Auteur** : Refactorisation par Claude  

🎨 **Couleurs bien organisées = Code maintenable !**
